var temps;
var ispay = false;


$(document).ready(function () {
    var eventContainer = $('body'); // events are attached to the body
  formr= eventContainer.find('#formr');
  formr=formr[0];
  console.log(formr)

  formr.onsubmit = function(e) {
   
      e.preventDefault();
      var fa = $(this);
      $(".payform").addClass("d-none");
      $(".loading").removeClass("d-none");
      $.ajax({
        url: fa.attr("action"),
        type: "post",
        data: fa.serialize(),
        dataType: "json",
        success: function (response) {
          if (response.status == "OK") {
            ispay = true;
            $("#exampleModalCenter").modal("hide");
            $("#confirmP").modal("show");
            $(".modal-backdrop").removeClass("modal-backdrop");
            $("#code_app").val(response.cle_app);
            $("#key").val(response.cle_operation);
            $("#code_sms").val(response.cle_sms);
            $(".trans_title").html(response.message);
            $(".resend").attr("data-url", response.url);
            $(".resend").attr("data-key", response.cle_operation);
          } else {
            ispay = false;
            $(".loading").addClass("d-none");
            $(".canceltranse").removeClass("d-none");
            $(".modal-footer").addClass("d-none");
            $(".response_messages").html("Transaction Failed");
            $(".trans_title").html(" Failed");
          }
        },
        error: function (error) {},
      });
    };
});


$("#exampleModalCenter").on("hidden.bs.modal", function () {
  if (!ispay) {
    $(".investchek").prop("checked", false);
  }
  $(".loading").addClass("d-none");
  $(".payform").removeClass("d-none");
});
$("#formr2").submit(function (e) {
  e.preventDefault();
  var fa = $(this);
  $(".loadinged").removeClass("d-none");
  $(".confirm").addClass("d-none");
  $.ajax({
    url: fa.attr("action"),
    type: "post",
    data: fa.serialize(),
    dataType: "json",
    success: function (response) {
      if (response.status == "OK") {
        ispay = true;
        $(".loadinged").addClass("d-none");
        $(".completetrans").removeClass("d-none");
        $(".modal-footer").addClass("d-none");
        $(".response_message").html("Transaction Complete");
        $(".trans_title").html(" Complete");
        $(".respo").html('<span class="text-success">Payment Receive</span>');
        $(".investchek").val("OK");
        $(".investchek").attr("readonly", true);
        var timeoutID = setTimeout(function () {
          location.href = response.redirect;
        }, 3000);
      } else if (response.status == "NOT OK") {
        ispay = false;
        $(".loadinged").addClass("d-none");
        $(".canceltrans").removeClass("d-none");
        $(".modal-footer").addClass("d-none");
        $(".response_message").html("Transaction Failed");
        $(".trans_title").html(" Failed");
      }
    },
    error: function (error) {},
  });
});

$(".resend").on("click", function () {
  $.ajax({
    type: "post",
    url: $(this).attr("data-url"),
    data: { key: $(this).attr("data-key") },
    dataType: "json",
    success: function (response) {
      if (response.status == "NOT OK") {
        ispay = false;
        $(".resend_message").html(
          '<span class="text-danger small">' +
            response.error_message +
            "</span>"
        );
      } else {
        ispay = true;
        $("#code_sms").val(response.cle_sms);
        $(".resend_message").html(
          '<span class="text-danger small">' + response.message + "</span>"
        );
      }
    },
  });
});
