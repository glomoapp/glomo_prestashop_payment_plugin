<?php
/*
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class GlomoInitiateModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {


        
        if (Glomo::getPost('action')) {


            $module = $this->module;
            $module instanceof Glomo;
            $order_id = (int) Glomo::getPost('order_id');
            $cart = new Cart($order_id);

            if (!$cart instanceof Cart) {
                exit;
            }

            $total = Tools::ps_round((float) $cart->getOrderTotal(true, Cart::BOTH), 0);
            
            switch (Tools::getValue('action')) {

                case 'initiate':




                    $data = [
                        'numero' => Glomo::getPost('number'),
                        'amount' => $total,
                        'title' => Glomo::getLabel(),
                    ];
                    
                    $param['option'] = Glomo::API_URL . Glomo::API_INI;
                    $response = $this->request($data, $param);

                    break;
                case "valider":


                    $data = [
                        'key' => Glomo::getPost('key'),
                        'code_app' => Glomo::getPost('code_app'),
                        'code_sms' => Glomo::getPost('code_sms'),
                    ];
                    $param['option'] = Glomo::API_URL . Glomo::API_VALIDER;
                    $response = $this->request($data, $param);
                    
                    $currency = $this->context->currency;
                    Glomo::getStatus($response, $module, $total, $cart, $order_id,$currency);
                    $response->redirect=Glomo::getServerUrl(). 'index.php?controller=order-confirmation&id_cart=' . $cart->id .'&id_module='. $this->id .'&id_order=' . $order_id . '&key=' . $cart->secure_key;
                    break;
                    case "resend":
                        $data = [
                            'key' => Glomo::getPost('key'),
                        ];
                        $param['option'] = Glomo::API_URL . Glomo::API_RESEND;
                        $response = $this->request($data, $param);
                    break;
                default:
                    break;
            }
        }

        $json = Tools::jsonEncode($response);
        $this->ajaxDie($json);
    }
    public function request($data, $param)
    {
        $url = $param['option'];
        // in this example, POST request was made using PHP's CURL
        $param['heard'] = [
            'App-Id: ' . Glomo::getApiKey(),
            'App-Secret:' . Glomo::getSecreKey(),
            'Authorisation: Bearer ' . Glomo::getApiTon(),
            'Content-Type: application/json',
            'Accept: application/json',
        ];
       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $param['heard']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        return json_decode($response);
    }
}
