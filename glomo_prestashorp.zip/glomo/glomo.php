<?php
/**
 * 
    Plugin Name: Glomo Money
    author:   Glomo Money <ionut@glomomoney.com>
    copyright: Copyright (c) permanent, Glomo Money
    version:  1.2.6
    Plugin URI:  https://glomomoney.com/
    Description: A Payment Gateway for Glomo Money Payments - Prestashop 1.7
 *
 */

 use PrestaShop\PrestaShop\Core\Payment\PaymentOption;
if ( ! defined( '_PS_VERSION_' ) ) {
	exit;
}

class Glomo extends PaymentModule 
{
    private $_html = '';

    public $address;
    const GLOMO_OS_SUCCESS_PAYMENT = 'GLOMO_OS_SUCCESS_PAYMENT';
    const GLOMO_OS_FAILED_PAYMENT = 'GLOMO_OS_FAILED_PAYMENT';
    const GLOMO_PAYMENT_DESCRIPTION = 'GLOMO_PAYMENT_DESCRIPTION';
    const API_URL = "https://apis.glomoapp.com/v1/";
    const API_INI = "/account/debit/initiate";
    const API_VALIDER = "/account/debit/valid";
    const API_RESEND = "/account/operation/code/sms/resend";
    /**
     * PrestaPay constructor.
     *
     * Set the information about this module
     */
    public function __construct()
    {
        $this->is_eu_compatible = 1;
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
        $this->name                   = 'glomo';
        $this->tab                    = 'payments_gateways';
        $this->version                = '1.8';
        $this->author                 = 'Glomo Money';
        parent::__construct();
        $this->displayName            = 'Glomo Money';
        $this->description            = 'A Payment Gateway for Glomo Money ';
        
       
    }

	public function install()
    {
        if (!parent::install()
        or ! $this->registerHook('displayPayment')
        or ! $this->registerHook('displayPaymentEU')
        or ! $this->registerHook('paymentOptions')
            ) {
                return false;
            }

            // Create Order States
            $this->addOrderStates(Glomo::GLOMO_OS_SUCCESS_PAYMENT, 'Glomo money Successful payment', '#086fd1', 'payment', true, true, true, true);
            $this->addOrderStates(Glomo::GLOMO_OS_FAILED_PAYMENT, 'Glomo money Payment failed', '#086fd1', '', false, false, false, false);
            return true;
    }
    public function uninstall()
    {
        if (!parent::uninstall()
                or ! $this->unregisterHook('displayPayment')
                or ! $this->unregisterHook('displayPaymentEU')
                or ! $this->unregisterHook('paymentOptions')
        ) {
            return false;
        }

        // Delete Order States
        $ordS1 = new OrderState(Configuration::get(Glomo::GLOMO_OS_SUCCESS_PAYMENT));
        $ordS1->delete();

        $ordS3 = new OrderState(Configuration::get(Glomo::GLOMO_OS_FAILED_PAYMENT));
        $ordS3->delete();

        // Clean configuration table
        Configuration::deleteByName("GLOMO_SECRET_KEY");
        Configuration::deleteByName("GLOMO_API_KEY");
        Configuration::deleteByName("GLOMO_TOKEN");
        Configuration::deleteByName("GLOMO_LABEL");

        Configuration::deleteByName(Glomo::GLOMO_OS_SUCCESS_PAYMENT);
        Configuration::deleteByName(Glomo::GLOMO_OS_FAILED_PAYMENT);
        Configuration::deleteByName(Glomo::GLOMO_PAYMENT_DESCRIPTION);

        return true;
    }
     /**
     * Admin configuration form
     */
    public function renderForm()
    {
        $fields_form = [
            'form' => [
                'legend' => [
                    'title' => 'Payment Configuration',
                    'icon' => 'icon-cogs'
                ],
                'description' => "",
                'input' => [
                    [
                        'type' => 'text',
                        'label' => 'App Secret key',
                        'name' => "GLOMO_SECRET_KEY",
                        'required' => true,
                        'empty_message' => $this->l('Please fill the payment App Secret key'),
                    ],
                    [
                        'type' => 'text',
                        'label' => 'App Id Key',
                        'name' => "GLOMO_API_KEY",
                        'required' => true,
                        'empty_message' => $this->l('Please fill the payment App Secret key'),
                    ],
                    [
                        'type' => 'text',
                        'label' => 'App Token',
                        'name' => "GLOMO_TOKEN",
                        'required' => true
                    ],
                    [
                        'type' => 'text',
                        'label' => 'Service Name',
                        'name' => "GLOMO_LABEL",
                        'required' => true
                    ],
                    [
                        'type' => 'textarea',
                        'label' => $this->l('Payment description on checkout page'),
                        'name' => Glomo::GLOMO_PAYMENT_DESCRIPTION,
                        'required' => true
                    ]
                ],
                'submit' => [
                    'title' => 'Save',
                    'class' => 'button btn btn-default pull-right',
                ],
            ],
        ];

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->id = 'glomo';
        $helper->identifier = 'glomo';
        $helper->submit_action = 'SubmitPaymentConfiguration';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = [
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        ];

        return $helper->generateForm(array($fields_form));
    }

    /**
     * Retrieving admin form configuration variables
     */
    public function getConfigFieldsValues()
    {
        return [
            "GLOMO_SECRET_KEY"=> Tools::getValue("GLOMO_SECRET_KEY", Configuration::get("GLOMO_SECRET_KEY")),
           "GLOMO_API_KEY" => Tools::getValue("GLOMO_API_KEY", Configuration::get("GLOMO_API_KEY")),
           "GLOMO_TOKEN"=> Tools::getValue("GLOMO_TOKEN", Configuration::get("GLOMO_TOKEN")),
           "GLOMO_LABEL"=> Tools::getValue("GLOMO_LABEL", Configuration::get("GLOMO_LABEL", null, null, null, "Glomo Money")),
           Glomo::GLOMO_PAYMENT_DESCRIPTION => Tools::getValue(Glomo::GLOMO_PAYMENT_DESCRIPTION, Configuration::get(Glomo::GLOMO_PAYMENT_DESCRIPTION, null, null, null, $this->l('Pay safely using your Glomo Money... account.')))

        ];
    }
    /**
     * @param array $params
     * @see hookPayment
     */
    public function hookDisplayPayment($params)
    {
        return $this->hookPayment($params);
    }

    /**
     * show module on payment step
     * this hook is used to output the current method of payment to the choice
     * list of available methods on the checkout pages.
     *
     * @param array $params
     * @return string
     */
    public function hookPayment($params)
    {
        return $this->hookPaymentOptions($params);
    }

    public function hookPaymentOptions($params)
    {
        $payment_options = [
            $this->getIframePaymentOption(),
        ];

        return $payment_options;
    }
    public function getIframePaymentOption()
    {
       
        $embeddedOption = new PaymentOption();
        $embeddedOption->setModuleName($this->name)
                       ->setCallToActionText($this->l('Glomo Money'))
                       ->setForm($this->generateForm())
                       ->setAdditionalInformation($this->fetch('module:glomo/views/templates/hook/glomo_info.tpl'));
        return $embeddedOption;
    }
    

    private function addOrderStates($key, $name, $color, $template, $invoice, $send_email, $paid, $logable)
    {
        // Create a new Order state if not already done
        if (!(Configuration::get($key) > 0)) {
            // Create a new state
            // and set the state
            // as Open

            $orderState = new OrderState(null, Configuration::get('PS_LANG_DEFAULT'));

            $orderState->name = $this->l($name);
            $orderState->invoice = $invoice;
            $orderState->send_email = $send_email;
            $orderState->module_name = $this->name;
            $orderState->color = $color;
            $orderState->unremovable = true;
            $orderState->hidden = false;
            $orderState->logable = $logable;
            $orderState->delivery = false;
            $orderState->shipped = false;
            $orderState->paid = $paid;
            $orderState->deleted = false;
            $orderState->template = $template;
            $orderState->add();

            // Update the value
            // in the configuration database
            Configuration::updateValue($key, $orderState->id);

            // Create an icon
            if (file_exists(PS_MODULE_DIR . $this->name . '/assets/img/os/logo_white_16.png')) {
                copy(PS_MODULE_DIR . $this->name
                        . '/assets/img/os/logo_white_16.png', PS_THEME_DIR
                        . '/assets/img/os/' . $orderState->id . '.png');
            }
        }
    }
 /**
     * Configuration content
     */
    public function getContent()
    {
        $this->_html .=$this->postProcess();
        $this->_html .= $this->renderForm();

        return $this->_html;
    }

    /**
     * Configuration processing
     * @return type
     */
    public function postProcess()
    {
        $result = false;
        if (Tools::isSubmit('SubmitPaymentConfiguration')) {
            $r = Configuration::updateValue("GLOMO_SECRET_KEY", Tools::getValue("GLOMO_SECRET_KEY"));
            $r2 = $r and Configuration::updateValue("GLOMO_API_KEY", Tools::getValue("GLOMO_API_KEY"));
            $r3 = $r2 and Configuration::updateValue("GLOMO_TOKEN", Tools::getValue("GLOMO_TOKEN"));
            $r4 = $r3 and Configuration::updateValue("GLOMO_LABEL", Tools::getValue("GLOMO_LABEL"));
            $result = $r4 and Configuration::updateValue(Glomo::GLOMO_PAYMENT_DESCRIPTION, Tools::getValue(Glomo::GLOMO_PAYMENT_DESCRIPTION));

            if ($result) {
                return $this->displayConfirmation($this->l('Configuration updated with success'));
            }

            return $this->displayWarning($this->l('Your configuration has not been saved'));
        }

        return '';
    }
    protected function generateForm()
    {
       
        $cart = $this->context->cart;
        $this->context->smarty->assign(array(
                    'payment_url' => $this->context->link->getModuleLink($this->name, 'initiate', array(), true),
                    'action'=>"initiate",
                    'action2'=>"valider",
                    "order_id"=>$cart->id,
                    "description"=>Glomo::getPaymentDescription(),
                    "base_url"=>Glomo::getServerUrl(),
                ));
        

        return $this->context->smarty->fetch('module:glomo/views/templates/hook/glomo_form.tpl');
    }
    /**
     * getSecretKey
     *
     * @return string
     */
    public static function getSecreKey()
    {
        return Configuration::get("GLOMO_SECRET_KEY");
    }

    /**
     * getApiKey
     * @return string
     */
    public static function getApiKey()
    {
        return Configuration::get("GLOMO_API_KEY");
    }
    
    /**
     * getApiTon
     * @return string
     */
    public static function getApiTon()
    {
        return Configuration::get("GLOMO_TOKEN");
    }
    
    public static function getLabel()
    {
        return Configuration::get("GLOMO_LABEL");
    }
    /**
     * getPost
     *
     * @param string $key
     * @param string $default
     * @return string | null
     */
    public static function getPost($key = null, $default = null)
    {
        return $key == null ? $_POST : (isset($_POST[$key]) ? $_POST[$key] : $default);
    }

    /**
     * getQuery
     *
     * @param string $key
     * @param string $default
     * @return string | null
     */
    public static function getQuery($key = null, $default = null)
    {
        return $key == null ? $_GET : (isset($_GET[$key]) ? $_GET[$key] : $default);
    }
    public static function getPaymentDescription()
    {
        return Configuration::get(Glomo::GLOMO_PAYMENT_DESCRIPTION);
    }
    
    public static function getStatus($reponse,$module,$total,$cart,$cart_id,$currency)
    {
        switch ($reponse->status) {
            case 'OK':
                $order_state = Configuration::get(Glomo::GLOMO_OS_SUCCESS_PAYMENT);
                $status = true;
                break;
            
            default:
            $order_state = Configuration::get(Glomo::GLOMO_OS_FAILED_PAYMENT);
            $status = false;
            break;
        }
        $customer = new Customer($cart->id_customer);
        $module->validateOrder($cart_id, $order_state, (float) $total, $module->displayName, null, array(), (int) $currency->id, false, $customer->secure_key);
        return $status ;
    }
    /**
     * getServerUrl
     *
     * @return string
     */
    public static function getServerUrl()
    {
        
        return Context::getContext()->shop->getBaseURL(true);
    }
}